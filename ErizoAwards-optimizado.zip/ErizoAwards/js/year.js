// Resalta la fila tocada en las tablas de ganadores
document.addEventListener('click', function (e) {
    var row = e.target.closest('.award-row');
    if (!row) return;
    document.querySelectorAll('.award-row.active').forEach(function (r) { r.classList.remove('active'); });
    row.classList.add('active');
});
