function toggleMusic() {
    var music = document.getElementById("bgMusic");
    var btn = document.getElementById("musicBtn");

    if (music.paused) {
        // play() devuelve una promesa: si el navegador lo bloquea, no rompemos nada
        music.play().then(function () {
            btn.innerHTML = "⏸️";
            btn.style.boxShadow = "0 0 25px #00ff00";
            btn.setAttribute("aria-label", "Pausar música");
        }).catch(function () {});
    } else {
        music.pause();
        btn.innerHTML = "🎵";
        btn.style.boxShadow = "0 0 15px #bf953f";
        btn.setAttribute("aria-label", "Activar música");
    }
}
